# Hello World CLI

This project creates a CLI tool using Typer to greet users.
