def main():
    print("Hello from ex-basics-1!")


if __name__ == "__main__":
    main()
