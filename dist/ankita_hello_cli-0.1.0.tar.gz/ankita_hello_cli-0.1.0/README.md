# ankita-hello-cli

A simple Python CLI tool that greets you by name!

## Installation

```bash
pip install -i https://test.pypi.org/simple/ ankita-hello-cli

